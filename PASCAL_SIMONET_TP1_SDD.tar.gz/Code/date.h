#ifndef DATE_H
#define DATE_H

#include <stdio.h>
#include <time.h>

int recuperer_date_courante();
void afficher_date_courante();

#endif